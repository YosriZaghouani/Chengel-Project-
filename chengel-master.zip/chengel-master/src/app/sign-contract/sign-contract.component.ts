import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-contract',
  templateUrl: './sign-contract.component.html',
  styleUrls: ['./sign-contract.component.css']
})
export class SignContractComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

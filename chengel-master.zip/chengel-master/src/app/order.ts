export interface Order {
    id?: any,
    title?: any,
    des?: any,
    date?: string,
    domaine?: string,
    price?: any,
    mail?: any,
    name?: any,
}